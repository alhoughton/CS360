package com.zybooks.weighttrackingapp_alhoughton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText username, password;
    private Button login, register;
    DatabaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.textName);
        password = (EditText) findViewById(R.id.textPassword);
        login = (Button) findViewById(R.id.buttonLogIn);
        register = (Button) findViewById(R.id.buttonRegister);
        database = new DatabaseHelper(this);

        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkLogIn = database.confirmLogIn(user, pass);
                    if(checkLogIn == true){
                        openDataActivity();
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Username/password doesn't match, try again", Toast.LENGTH_SHORT).show();
                        // clears password so user can type a new one in
                        password.setText(null);
                    }
                }

            }
        });


        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                String user = username.getText().toString();
                String pass = password.getText().toString();

                if(user.equals("") || pass.equals("")){
                    Toast.makeText(MainActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUser = database.checkUsername(user);
                    if(checkUser == false){
                        Boolean insert = database.registerUser(user, pass);
                        if(insert == true){
                            openDataActivity();
                        }
                    }
                    else{
                        Toast.makeText(MainActivity.this, "User already exists, please log in", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

    }

    public void openDataActivity(){
        Intent intent = new Intent(this, dataDisplay.class);
        intent.putExtra("username", username.getText().toString()); //this will only store a username if a username exists based on logic above
        startActivity(intent);
    }
}