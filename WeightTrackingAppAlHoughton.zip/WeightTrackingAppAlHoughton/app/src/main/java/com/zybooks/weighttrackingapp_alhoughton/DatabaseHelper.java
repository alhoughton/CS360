package com.zybooks.weighttrackingapp_alhoughton;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper( Context context) {
        super(context, "WeightTracker.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase myDB) {

        myDB.execSQL("CREATE Table users(username TEXT primary key, password TEXT)");
        myDB.execSQL("CREATE Table dailyWeights(id INTEGER primary key autoincrement, username TEXT, weight TEXT, date TEXT)");
        myDB.execSQL("CREATE Table goalWeights (username TEXT primary key, goalWeight TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {

        myDB.execSQL("drop Table if exists users");
        myDB.execSQL("drop Table if exists dailyWeights");
        myDB.execSQL("drop Table if exists goalWeights");
        onCreate(myDB);

    }

    // create a method to register a user
    public Boolean registerUser(String username, String password){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        long successful = myDB.insert("users", null, cv);
        myDB.close();
        if (successful == -1){
            return false;
        }
        else
            return true;
    }


    // checks to see if user name is in database
    public Boolean checkUsername(String username){
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public Boolean confirmLogIn (String username, String password){
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from users where username = ? and password = ?",
                new String[]{username, password});
        if(cursor.getCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }


    // create a method to insert data
    public Boolean setCurrentWeight(String username, String cweight, String cDate){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("weight", cweight);
        cv.put("date", cDate);
        long successful = myDB.insert("dailyWeights", null, cv);
        myDB.close();
        if (successful == -1){
            return false;
        }
        else
            return true;

    }

    public Cursor getAllWeights(String username){
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from dailyWeights where username=?", new String[] {username});

        return cursor;
    }

    public Boolean setGoalWeight(String username, String gWeight){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("goalWeight", gWeight);
        long success;
        //load data row into cursor object
        Cursor cursor = myDB.rawQuery("Select * from goalWeights where username=?", new String[] {username});
        //if cursor object contains data, then run update, else run insert
        if(cursor.getCount() > 0){
            success = myDB.update("goalWeights", cv, "username=?", new String[]{username});
            myDB.close();
        }
        else{
            cv.put("username", username);
            success = myDB.insert("goalWeights", null, cv);
            myDB.close();
        }

        if (success == -1){
            return false;
        }
        else{
            return true;
        }

    }

    public Cursor getGoalWeight(String username){
        SQLiteDatabase myDB = this.getReadableDatabase();
        Cursor cursor = myDB.rawQuery("Select * from goalWeights where username=?", new String[] {username});
        return cursor;
    }

    public Boolean deleteWeight(int wtId){
        SQLiteDatabase myDB = this.getWritableDatabase();
        long success = myDB.delete("dailyWeights", "date=?", new String[]{String.valueOf(wtId)});
        myDB.close();

        if (success == -1){
            return false;
        }
        else{
            return true;
        }


    }

    public Boolean updateWeight(String weight, int wtId){
        SQLiteDatabase myDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("weight", weight);
        long success = myDB.update("dailyWeights", cv,"date=?", new String[] {String.valueOf(wtId)});
        myDB.close();

        if (success == -1){
            return false;
        }
        else{
            return true;
        }

    }

}
