package com.zybooks.weighttrackingapp_alhoughton;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

public class dataDisplay extends AppCompatActivity {

    Button smsPermission, addWt,updateGoal, deleteEntry, update;
    EditText curWt, curDate, goalWt;
    TextView weight, date, id;
    DatabaseHelper database;
    Cursor allWeights, goalWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);
        curWt = (EditText) findViewById(R.id.currentWeight);
        curDate = (EditText) findViewById(R.id.dateEntered);
        goalWt = (EditText) findViewById(R.id.goalWeight);
        weight = (TextView) findViewById(R.id.tv_cWeight);
        date = (TextView) findViewById(R.id.tv_cDate);
        id = (TextView) findViewById(R.id.tv_ID);

        // buttons
        smsPermission = (Button) findViewById(R.id.btnSmsNotifcation);
        addWt = (Button) findViewById(R.id.btnAdd);
        deleteEntry = (Button) findViewById(R.id.btnDelete);
        updateGoal = (Button) findViewById(R.id.btnGoalWeight);
        update = (Button) findViewById(R.id.btn_Update);

        // gets and stores username passed from login/register activity
        String username = getIntent().getStringExtra("username");

        database = new DatabaseHelper(this);

        allWeights = database.getAllWeights(username);
        //runs through list to add dailyWeight data to table
        while(allWeights.moveToNext()){
            String tempId = String.valueOf(allWeights.getInt(0));
            String tempWeight = allWeights.getString(2);
            String tempDate = allWeights.getString(3);
            id.setText(tempId);
            weight.setText(tempWeight);
            date.setText(tempDate);
        }

        goalWeight = database.getGoalWeight(username);
        while (goalWeight.moveToNext()){
            String tempGoalWeight = goalWeight.getString(1);
            goalWt.setText(tempGoalWeight);
        }



        if(goalWt.getText().toString().equals("")){
            Toast.makeText(this, "Please update Goal Weight", Toast.LENGTH_SHORT).show();
        }


        // grants permission to send SMS message
        smsPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //first check to see if permission has already been granted
                if(getApplicationContext().checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(dataDisplay.this, "SMS Text Permission previously granted", Toast.LENGTH_SHORT).show();
                }
                else{
                    requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 1);
                }
            }
        });

        addWt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputWt = curWt.getText().toString();
                String inputDate = curDate.getText().toString();

                Boolean insertData = database.setCurrentWeight(username, inputWt, inputDate);

                if (insertData == true){
                    Toast.makeText(dataDisplay.this, "Data successfully added", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(dataDisplay.this, "Data not added", Toast.LENGTH_SHORT).show();
                }
            }
        });

        updateGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String inputGoal = goalWt.getText().toString();

                Boolean insertData = database.setGoalWeight(username, inputGoal);

                if (insertData == true){
                    Toast.makeText(dataDisplay.this, "Data successfully added", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(dataDisplay.this, "Data not added", Toast.LENGTH_SHORT).show();

                }
            }
        });

        deleteEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int rowId = Integer.parseInt(id.getText().toString());

                Boolean deleteData = database.deleteWeight(rowId);

                if (deleteData == true){
                    Toast.makeText(dataDisplay.this, "Data successfully deleted", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(dataDisplay.this, "Data not deleted", Toast.LENGTH_SHORT).show();

                }
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int rowId = Integer.parseInt(id.getText().toString());
                String tempWeight = curWt.getText().toString();

                Boolean updateData = database.updateWeight(tempWeight, rowId);

                if (updateData == true){
                    Toast.makeText(dataDisplay.this, "Data successfully updated", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(dataDisplay.this, "Data not updated", Toast.LENGTH_SHORT).show();

                }
            }
        });



    }



}